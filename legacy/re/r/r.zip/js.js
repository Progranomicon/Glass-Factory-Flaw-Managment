function step1(item_t){
    var text;
    var elem=document.getElementById('step2');  
    document.getElementById('step3').innerHTML='';
    text='';
    text+='<Select name="goal" onchange="step2(this.options[this.selectedIndex].value, '+item_t+');">\n\
            <option selected value="0">-Ваша цель-</option>\n\
            <option value="1">Продать</option>';
    if (item_t==1 | item_t==2){
         text+=' <option value="2">Сдать посуточно</option>';
    }
    if (item_t==1 | item_t==2 | item_t==4){
         text+=' <option value="3">Сдать долгосрочно</option>';
    }
    text+='</select>';
    if (item_t==0){
         text='';
         document.getElementById('step3').innerHTML='';
         document.getElementById('step2').innerHTML='';
    }
    if (item_t!=0){
       elem.innerHTML='<IMG SRC="step2.PNG" style="float:left; z-index: 3;"><br>'+text+'<br><br>'; 
    }
    
}
function step2(item_t /*текущий*/, item_p /*предыдущий*/)
{
    var text;
    var elem=document.getElementById('step3');
    text='';	
	if (item_p==1)
	{
		text+=' <Select name="house_type" > \n\
					<option selected value="0">-Тип дома-</option>\n\
					<option value="1">Литовка</option> \n\
					<option value="2">Кирпичный</option>\n\
					<option value="3">Панельный</option>\n\
					<option value="4">Еще какой-нибудь</option>\n\
				</select><br><br>';
		text+='<Select name="rooms_count" > \n\
					<option selected value="0">-Сколько комнат-</option>\n\
					<option value="1">1</option> \n\
					<option value="2">2</option>\n\
					<option value="3">3</option>\n\
					<option value="4">4+</option>\n\
				</select><br><br>';
		text+='Общая площадь : <input id=Price type="text" name="S" value="50"> м<sup>2</sup>.<br><br>';
		text+='Жилая площадь: <input id=Price type="text" name="S" value="40"> м<sup>2</sup>.<br><br>';
		text+='Площадь кухни: <input id=Price type="text" name="S" value="6"> м<sup>2</sup>.<br><br>';
		text+=print_floor_and_number_of_storeys();
				text+=' <label> Новостройка <input name="hands" type="radio" value=1 ></label> \n\
						<label> Вторичное <input name="hands" type="radio" value=2 checked></label>\n\
					<br><br>';
	}
	if (item_p==2)
    {
        text+=' <Select name="house_type" > \n\
					<option selected value="0">-Материал стен-</option>\n\
					<option value="11">Кирпич</option> \n\
					<option value="12">Дерево</option>\n\
					<option value="13">Другой</option>\n\
				</select><br><br>';
		text+='<Select name="rooms_count" > \n\
					<option selected value="0">-Сколько комнат-</option>\n\
					<option value="1">1</option> \n\
					<option value="2">2</option>\n\
					<option value="3">3</option>\n\
					<option value="4">4+</option>\n\
				</select><br><br>';
		text+='Общая площадь : <input id=Price type="text" name="S" value="100"> м<sup>2</sup>.<br><br>';
		text+='Жилая площадь: <input id=Price type="text" name="S" value="70"> м<sup>2</sup>.<br><br>';
		text+='Площадь кухни: <input id=Price type="text" name="S" value="10"> м<sup>2</sup>.<br><br>';
		text+='Количество этажей: <Select name="number_of_storeys" > \n\
					<option selected value="0">-этажность-</option>\n\
					<option value="1">1</option>\n\
					<option value="2">2</option>\n\
					<option value="3">3</option>\n\
					<option value="4">4</option>\n\
				</Select> .<br><br>';
    }
	if (item_p==3)
	{
		text+='Общая площадь : <input id=Price type="text" name="S" value="15"> соток.<br><br>';
	}
	if (item_p==4)
	{
		text+=' <Select name="house_type" > \n\
					<option selected value="0">-Тип объекта-</option>\n\
					<option value="1">Офис</option> \n\
					<option value="2">Склад</option>\n\
					<option value="3">Торговые помещения</option>\n\
					<option value="4">Другое</option>\n\
				</select><br><br>';
		text+='Общая площадь : <input id=Price type="text" name="S" value="50"> м<sup>2</sup>.<br><br>';
		text+=print_floor_and_number_of_storeys();
	}
    if (item_t==1)
    {
         text+='Цена: <input id=Price type="text" name="Price" value="1000000"> рублей.<br><br>';
    }
    if (item_t==2)
    {
         text+='Цена: <input id=Price type="text" name="Price" value="1000"> рублей за сутки.<br><br>';
    }
    if (item_t==3)
    {
         text+='Цена: <input id=Price type="text" name="Price" value="7000"> рублей за месяц.<br><br>';
    }
    
    text+='Дополнительные сведения <br>\
<textarea placeholder="Что на ваш взгляд нам еще важно знать о вашем объекте" cols="58" rows="6" name="comment"></textarea><br><br>';
	text+='Адрес <br>\
<textarea placeholder="Адрес, где находится объект" cols="58" rows="6" name="address"></textarea><br><br>';
	text+='Телефон: <input  type="text" name="phone" value=""><br><br>';
	text+='Альтернативный телефон: <input  type="text" name="phone2" value=""> <br><br>';
	text+='Электропочта: <input  type="text" name="email" value="aaa@bbb.ru"> <br><br>';
	text+='<input  type="submit" value="Отправить"><br></form><br>';
    elem.innerHTML='<IMG SRC="step3.PNG" style="float:left; z-index: 4;"><br>'+text;
    if (item_t==0)
    {
         document.getElementById('step3').innerHTML='';
    }
}

function print_floor_and_number_of_storeys()
{
	return 'Этаж: <Select name="floor" > \n\
					<option selected value="0">-этаж-</option>\n\
					<option value="1">1</option> \n\
					<option value="2">2</option>\n\
					<option value="3">3</option>\n\
					<option value="4">4</option>\n\
					<option value="5">5</option>\n\
					<option value="6">6</option>\n\
					<option value="7">7</option>\n\
					<option value="8">8</option>\n\
					<option value="9">9</option>\n\
					<option value="10">10</option>\n\
					<option value="11">11</option>\n\
					<option value="12">12</option>\n\
					<option value="13">13</option>\n\
					<option value="14">14</option>\n\
					<option value="15">15</option>\n\
					<option value="16">16</option>\n\
					<option value="17">17</option>\n\
					<option value="18">18</option>\n\
					<option value="19">19</option>\n\
					<option value="20">20</option>\n\
					<option value="21">21</option>\n\
					<option value="22">22</option>\n\
				</select> \n\
				в <Select name="number_of_storeys" > \n\
					<option selected value="0">-этажность-</option>\n\
					<option value="1">1-но</option> \n\
					<option value="2">2-ух</option>\n\
					<option value="3">3-х</option>\n\
					<option value="4">4-х</option>\n\
					<option value="5">5-ти</option>\n\
					<option value="6">6-ти</option>\n\
					<option value="7">7-ми</option>\n\
					<option value="8">8-ми</option>\n\
					<option value="9">9-ти</option>\n\
					<option value="10">10-ти</option>\n\
					<option value="11">11-ти</option>\n\
					<option value="12">12-ти</option>\n\
					<option value="13">13-ти</option>\n\
					<option value="14">14-ти</option>\n\
					<option value="15">15-ти</option>\n\
					<option value="16">16-ти</option>\n\
					<option value="17">17-ти</option>\n\
					<option value="18">18-ти</option>\n\
					<option value="19">19-ти</option>\n\
					<option value="20">20-ти</option>\n\
					<option value="21">21-но</option>\n\
					<option value="22">22-ух</option>\n\
				</select> этажном доме<br><br> ';
}
